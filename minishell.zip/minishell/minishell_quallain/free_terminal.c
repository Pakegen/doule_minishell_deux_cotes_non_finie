/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   free_terminal.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qacjl <qacjl@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:24:38 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/27 16:24:47 by qacjl            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	free_2d_array(char **strs)
{
	int	i;

	if (strs == NULL)
		return ;
	i = 0;
	while (strs[i] != NULL)
	{
		free(strs[i]);
		i = i + 1;
	}
	free(strs);
}

void	free_prompt(t_prompt *prompt)
{
	free(prompt->cmd_line);
	free_2d_array(prompt->strs);
}

void	free_terminal(t_shell *shell)
{
	free(shell->path);
	free(shell->pwd);
	free(shell->old_pwd);
	free_2d_array(shell->splitted_path);
	free_2d_array(shell->export);
	free_2d_array(shell->var_names);
	ft_lstclear(&shell->env_lines, &free);
	free(shell);
}
