/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   minishell.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:02:49 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/28 17:22:31 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef MINISHELL_H
# define MINISHELL_H

# define MAX_ARGS 64

# include <readline/readline.h>
# include <readline/history.h>
# include <linux/limits.h>
# include <signal.h>
# include <sys/wait.h>
# include "libft/libft.h"

typedef struct s_command
{
	char	**args;
	char	*heredoc_delim;
}	t_command;

typedef struct s_pipeline
{
	t_command	*commands;
	int			count;
}	t_pipeline;

typedef struct s_exec_context
{
	t_pipeline	*pipeline;
	char		**env;
	int			cmd_count;
}	t_exec_context;

typedef struct s_shell
{
	int		shlvl;
	char	*path;
	char	*pwd;
	char	*old_pwd;
	char	**splitted_path;
	char	**export;
	char	**var_names;
	t_list	*env_lines;
	t_list	*export_lines;
	t_list	*vars;
}	t_shell;

typedef struct s_prompt
{
	char	*cmd_line;
	char	*echo;
	char	**strs;
}	t_prompt;

typedef enum e_state
{
	STATE_DEFAULT,
	STATE_IN_SINGLE,
	STATE_IN_DOUBLE,
	STATE_ESCAPING
}	t_state;

typedef struct s_tokenize_context {
	int			i;
	int			ti;
	char		**tokens;
	char		*curr;
	t_state		state;
}	t_tokenize_context;

void		process_default(char c, t_state *state, char **curr);
void		process_in_single(char c, t_state *state, char **curr);
void		process_in_double(char c, t_state *state, char **curr);
void		process_escaping(char c, t_state *state, char **curr);
char		**advanced_tokenize(const char *line);
int			adv_handle_redirect(const char *target, const char *op, int std_fd);
int			handle_redirection_char(const char *file, const char *op);
int			count_quotes(const char *cmd_line);
int			check_path_validity(char *cmd);
int			existing_command(char **paths, char *cmd);
char		**parse_echo(t_prompt *prompt);
char		*exec_echo(char *cmd_line, char **strs);
char		*join_strings(char **strs);
void		exec_export(t_shell *shell, t_prompt *prompt);
void		exec_unset(t_shell *shell, t_prompt *prompt);
void		find_env_line(t_shell *shell, char *var, t_list **lst);
void		remove_line(t_list **lst, char *line);
void		free_2d_array(char **strs);
void		free_prompt(t_prompt *prompt);
void		free_terminal(t_shell *shell);
void		exec_setenv(t_shell *shell, t_prompt *prompt);
void		exec_unsetenv(t_shell *shell, t_prompt *prompt);
char		*find_path_line(char **envp);
char		*get_pwd(char **envp);
int			get_shell_level(char **envp);
char		**split_path(char **envp);
char		**split_path_from_value(const char *path_value);
char		*expand_variables(const char *input);
void		exec_cd(t_shell *shell, t_prompt *prompt);
void		update_paths(t_shell *shell, t_list *lst);
void		update_paths_export(t_shell *shell, t_list *lst);
char		*get_command_path(char *cmd, char **env);
void		ft_swap(char **s1, char **s2);
void		sort_strings(char **envp, int size);
char		*find_third_word(const char *cmd_line);
int			handle_heredoc(const char *delimiter);
void		display_history(void);
void		verif_history(const char *input);
void		execute_command(char *cmd, int in_fd, int out_fd);
void		execute_pipes(char *input);
void		parse_command_line(char *line);
int			is_valid(char *cmd_line);
t_pipeline	*parse_input(const char *line);
void		free_pipeline(t_pipeline *pipeline);
void		handle_pipe(char *cmd1[], char *cmd2[]);
void		execute_pipeline(t_pipeline *pipeline, char **env);
char		*save_text(int fd);
int			count_strings(char **strs);
char		**get_lines(char **envp);
char		**get_var_names(char **envp);
char		**get_lines_export(char **envp);
int			redirect_file(const char *target, int std_fd, int flags, int mode);
int			calculate_size_for_replace(const char *str, char *a, char *b);
char		*replace(const char *str, char *a, char *b);
void		setup_signal(void);
void		handle_sigint(int sig);
void		handle_sigquit(int sig);
char		*ft_strcpy(char *dest, const char *src);
int			ft_strcmp(const char *s1, const char *s2);
int			count_occurrences(const char *cmd_line, int to_find);
int			count_words(const char *str);
char		*ft_strndup(const char *src, size_t n);
void		write_env(t_list *lst);
int			calculate_total_size(int size, char **strs, char *sep);
char		*ft_strjoin2(int size, char **strs, char *sep);
char		*copy_line_with_quotes(char *src);

#endif
