/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   write_content.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:38:18 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/28 14:30:16 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	write_env(t_list *lst)
{
	t_list	*temp;

	temp = lst;
	while (temp != NULL)
	{
		ft_printf("%s\n", temp->content);
		temp = temp->next;
	}
}

int	calculate_total_size(int size, char **strs, char *sep)
{
	int	i;
	int	total_size;

	i = 0;
	total_size = 0;
	while (i < size)
	{
		total_size += ft_strlen(strs[i]);
		if (i < size - 1)
			total_size += ft_strlen(sep);
		i = i + 1;
	}
	return (total_size);
}

char	*ft_strjoin2(int size, char **strs, char *sep)
{
	int		i;
	int		j;
	int		total_size;
	char	*new_string;

	i = 0;
	j = 0;
	total_size = calculate_total_size(size, strs, sep);
	new_string = malloc(sizeof(char) * (total_size + 1));
	if (new_string == NULL)
		return (NULL);
	while (i < size)
	{
		ft_strcpy(new_string + j, strs[i]);
		j += ft_strlen(strs[i]);
		if (i < size - 1)
		{
			ft_strcpy(new_string + j, sep);
			j += ft_strlen(sep);
		}
		i = i + 1;
	}
	new_string[total_size] = '\0';
	return (new_string);
}

char	*copy_line_with_quotes(char *src)
{
	int		i;
	int		j;
	char	*dest;

	i = 0;
	j = 0;
	dest = malloc(sizeof(char) * (ft_strlen(src) + 3));
	if (dest == NULL)
		return (NULL);
	while (src[i] != '\0' && src[i] != '=')
	{
		dest[j] = src[i];
		i = i + 1;
		j = j + 1;
	}
	if (src[i] == '=')
	{
		dest[j] = src[i];
		j = j + 1;
		i = i + 1;
	}
	dest[j] = '"';
	j = j + 1;
	while (src[i] != '\0')
	{
		dest[j] = src[i];
		i = i + 1;
		j = j + 1;
	}
	dest[j] = '"';
	j = j + 1;
	dest[j] = '\0';
	return (dest);
}
