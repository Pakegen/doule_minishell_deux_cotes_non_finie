/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   replace.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:35:45 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/28 15:32:51 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	count_occurrences2(const char *str, char *to_find)
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	while (str[i] != '\0')
	{
		if (ft_strncmp(str + i, to_find, ft_strlen(to_find)) == 0)
			count = count + 1;
		i = i + 1;
	}
	return (count);
}

int	calculate_size_for_replace(const char *str, char *a, char *b)
{
	int	difference;
	int	length;

	difference = (ft_strlen(b) - ft_strlen(a))
		* count_occurrences2(str, a);
	length = ft_strlen(str) + difference;
	return (length);
}

char	*replace(const char *str, char *a, char *b)
{
	int		i;
	int		size;
	int		total_size;
	char	*new_string;

	i = 0;
	total_size = calculate_size_for_replace(str, a, b);
	new_string = malloc(sizeof(char) * (total_size + 1));
	if (new_string == NULL)
		return (NULL);
	while (*str != '\0')
	{
		if (ft_strncmp(str, a, ft_strlen(a)) == 0)
		{
			size = 0;
			while (b[size] != '\0')
			{
				new_string[i] = b[size];
				i = i + 1;
				size = size + 1;
			}
			str = str + ft_strlen(a);
		}
		else
		{
			new_string[i] = *str;
			i = i + 1;
			str = str + 1;
		}
	}
	new_string[i] = '\0';
	return (new_string);
}
