/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exec_echo.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: quenalla <quenalla@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:22:20 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/28 14:24:58 by quenalla         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

static void	check_each_string(char *echo, char **strs, int quote)
{
	char	**splitted_str;
	int		i;
	int		j;
	int		count;

	i = 0;
	j = 0;
	count = 0;
	while (echo[i] != '\0')
	{
		if (echo[i] == quote)
			count = count + 1;
		if (ft_strcmp(echo + i, strs[j]) == 0)
		{
			if (count % 2 == 0)
			{
				i = i + ft_strlen(strs[j]);
				splitted_str = ft_split(strs[j], ' ');
				strs[j] = ft_strjoin2(count_words(strs[j]),
						splitted_str, " - ");
				free_2d_array(splitted_str);
			}
			j = j + 1;
		}
		i = i + 1;
	}
}

char	**parse_echo(t_prompt *prompt)
{
	char	**strs;
	int		i;
	int		quote;

	i = 0;
	while (prompt->echo[i] != '\0'
		&& prompt->echo[i] != '\''
		&& prompt->echo[i] != '"')
	{
		i = i + 1;
	}
	if (prompt->echo[i] == '\'')
		quote = prompt->echo[i];
	else
		quote = '"';
	strs = ft_split(prompt->echo, quote);
	check_each_string(prompt->echo, strs, quote);
	return (strs);
}

char	*exec_echo(char *cmd_line, char **strs)
{
	char	*echo;

	if (count_quotes(cmd_line) == 0)
		echo = ft_strjoin2(count_words(cmd_line) - 2,
				(strs + 2), " ");
	else if (count_quotes(cmd_line) % 2 == 1)
		echo = ft_strdup("Error\n");
	else
		echo = find_third_word(cmd_line);
	return (echo);
}

char	*join_strings(char **strs)
{
	char	*joined_str;

	joined_str = ft_strjoin2(count_strings(strs), strs, "");
	return (joined_str);
}
